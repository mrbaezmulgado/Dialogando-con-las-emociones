# Dialogando con la Emoción
Prototipo inicial del juego.