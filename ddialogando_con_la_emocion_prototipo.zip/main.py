# Placeholder del prototipo
print('Dialogando con la Emoción - Prototipo')